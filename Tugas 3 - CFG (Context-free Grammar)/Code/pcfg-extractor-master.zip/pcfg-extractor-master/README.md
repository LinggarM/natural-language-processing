# pcfg-extractor
Probabilistic context free grammars extractor for indonesian-tagged-corpus
